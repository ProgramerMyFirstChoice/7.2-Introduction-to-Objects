﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IntroToObjectAssignment
{
    /* Nahom Gebreyohannies
         * 
         * CSI 154
         * 
         * February 18, 2018
         * 
         * Code assignment 7.2 Introduction to Objects
         */
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnDisplayInput_Click(object sender, EventArgs e)
        {
            if (IsValidData())
            {
                // CLear the rich display first
                richDisplay.Clear();

                // Creat the Car object
                Car car = new Car();
                
                // Assign value to object
                car.Make = txtMake.Text;
                car.Model = txtModel.Text;
                car.Color = txtColor.Text;
                car.Year = Convert.ToInt16(txtYear.Text);
                car.Mileage = Convert.ToDecimal(txtMileage.Text);
                car.Price = Convert.ToDecimal(txtPrice.Text);

                // Display the input in richbox
                Display(car);
      
            } 
            
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (IsValidData())
            {
                // Declare a StreamWriter variable
                StreamWriter outputFile;

                // Create a file and get a StreamWriter object.
                outputFile = File.AppendText("FilesCS.txt");

                // Write the calcualted value content to the file.
                outputFile.WriteLine(txtMake.Text + ", " + txtModel.Text + ", " +
                                     txtColor.Text + ", " + txtYear.Text + ", " +
                                     txtMileage.Text + ", " + txtPrice.Text);

                // Close the StreamWriter
                outputFile.Close();

                // Let the user know the array values was written
                MessageBox.Show("Done");
            }

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // Clear the input and outpu
            txtMake.Clear();
            txtModel.Clear();
            txtColor.Clear();
            txtYear.Clear();
            txtMileage.Clear();            
            txtPrice.Clear();
            richDisplay.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }

        // Method that display the user input about the car in richbox
        private void Display(Car car1)
        {
            richDisplay.AppendText("Make of the Car:        " + car1.Make + "\n" +
                                   "Model of the Car:       " + car1.Model + "\n" +
                                   "Color of the Car:       " + car1.Color + "\n" +
                                   "Year of the Car:        " + car1.Year + "\n" +
                                   "Mileage of the Car:     " + car1.Mileage + "\n" +
                                   "Price of the Car:       " + car1.Price + "\n");

        }

        #region Validation          
        public bool IsValidData()
            {
            return
            // Validate Make
            IsPresent(txtMake, "Make") &&

            // Validate Model
            IsPresent(txtModel, "Model") &&

            // Validate Color
            IsPresent(txtColor, "Color") &&


            // Validate Year
            IsPresent(txtYear, "Year") &&
            IsNumber(txtYear, "Year") &&

            // Validate Mileage
            IsPresent(txtMileage, "Mileage") &&
            IsNumber(txtMileage, "Mileage") &&

            // Validate Price
            IsPresent(txtPrice, "Price") &&
            IsNumber(txtPrice, "Price");
           
            }
        // Validates the text box is not empty
        public bool IsPresent(TextBox textBox, string name)
            {
                if (String.IsNullOrEmpty(textBox.Text))
                {
                    MessageBox.Show(name + " is a reqiured field.", "Entry Error");
                    textBox.Focus();
                    return false;
                }

                return true;
            }

        // Validate the textbox number is a number
        public bool IsNumber(TextBox textBox, string name)
            {
                double number = 0;
                if (double.TryParse(textBox.Text, out number) && number > 0)
                {
                    return true;
                }
                else
                {
                    MessageBox.Show(name + " must be a positive number ", "Entry Error");
                    textBox.Focus();
                    return false;
                }
            }
        #endregion

    }
}

