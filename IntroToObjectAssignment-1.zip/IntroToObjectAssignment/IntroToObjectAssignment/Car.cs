﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntroToObjectAssignment
{
    class Car
    {
        // Fields
        private string make;
        private string model;
        private string color;
        private int year;
        private decimal mileage;
        private decimal price;

        public Car()
        {
            make = "";
            model = "";
            color = "";
            year = 0;
            mileage = 0m;
            price = 0m;
        }

        // Make property
        public string Make { get { return make; } set { make = value;}}

        // Model Property
        public string Model { get { return model; } set { model = value; }}

        // Color Property
        public string Color { get { return color; } set { color = value; }}

        // Year Property
        public int Year { get { return year; } set { year = value; } }

        // Mileade Property
        public decimal Mileage { get { return mileage; } set { mileage = value; } }

        // Price Property
        public decimal Price { get { return price; } set { price = value; } }

    }
}
 